from .config_email import send

__all__ = ["send"]
