import setuptools
# The directory containing this file
import pathlib
HERE = pathlib.Path(__file__).parent

# The text of the README file
README = (HERE / "README.md").read_text()
setuptools.setup(
    name="pbl6package",
    version="0.0.1",
    author="Group2",
    description="PBL6",
    long_description="Package Config PBL6",
    long_description_content_type="text/markdown",
    packages=[
        'config',
        'emailhelper',
    ],
    readme = "README.md",
    license='MIT',
    url="https://github.com/banhmysuawx/PBL6-BE",
    keywords=["django", "djangorestframework", "drf", "rest-client",],
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)